import os   

os.system('python V2/fromtele/fetch/fetch.py')
os.system('python V2/fromtele/merge/start.py')
os.system('python V2/fromtele/merge/clean.py')
os.system('python V2/fromtele/seprate/3hy2.py')
os.system('python V2/fromtele/seprate/3hysteria.py')
os.system('python V2/fromtele/seprate/3juicity.py')
os.system('python V2/fromtele/seprate/3ss.py')
os.system('python V2/fromtele/seprate/3ssr.py')
os.system('python V2/fromtele/seprate/3trojan.py')
os.system('python V2/fromtele/seprate/3tuic.py')
os.system('python V2/fromtele/seprate/3vmess.py')
os.system('python V2/fromtele/seprate/3vless.py')
