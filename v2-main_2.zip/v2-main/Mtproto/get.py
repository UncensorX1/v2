import os   

os.system('python Mtproto/run/1.py && python Mtproto/run/2.py && python Mtproto/run/3.py && python Mtproto/run/4.py && python Mtproto/run/5.py && python Mtproto/run/6.py && python Mtproto/run/7.py && python Mtproto/run/8.py && python Mtproto/run/9.py && python Mtproto/run/copy.py')
