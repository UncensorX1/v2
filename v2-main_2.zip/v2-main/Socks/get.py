import os   

os.system('python Socks/run/1.py && python Socks/run/2.py && python Socks/run/3.py && python Socks/run/4.py && python Socks/run/5.py && python Socks/run/6.py && python Socks/run/copy.py')
